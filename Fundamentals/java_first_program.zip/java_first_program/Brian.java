public class Brian {
	public static void main(String[] args) {
        System.out.println("Hi my name is Brian Lester");
        System.out.println("I am 26 years old");
        System.out.println("My hometown in Lanoka Harbor NJ");
	}
}
